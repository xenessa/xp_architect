"""
XP Architect API Test Script
Tests the backend API directly without a browser.
Run: python test_api.py
"""

import requests
import time
import random
import string

# Configuration
BASE_URL = "https://xparchitect-production.up.railway.app"  # Change for local: http://localhost:8000

def random_email():
    """Generate a random email for testing."""
    suffix = ''.join(random.choices(string.ascii_lowercase + string.digits, k=8))
    return f"test_{suffix}@example.com"

def print_section(title):
    print(f"\n{'='*60}")
    print(f"  {title}")
    print(f"{'='*60}\n")

def print_response(label, data, truncate=500):
    """Pretty print a response, truncating long values."""
    if isinstance(data, dict):
        print(f"{label}:")
        for key, value in data.items():
            str_val = str(value)
            if len(str_val) > truncate:
                str_val = str_val[:truncate] + "..."
            print(f"  {key}: {str_val}")
    else:
        print(f"{label}: {data}")


class XPArchitectTester:
    def __init__(self, base_url=BASE_URL):
        self.base_url = base_url
        self.sa_token = None
        self.stakeholder_token = None
        self.project_id = None
        self.invite_token = None
        
    def register_sa(self, email=None, password="test123", name="Test SA"):
        """Register a Solution Architect account."""
        email = email or random_email()
        print(f"Registering SA: {email}")
        
        resp = requests.post(f"{self.base_url}/api/auth/register", json={
            "email": email,
            "password": password,
            "name": name,
            "role": "SA"
        })
        
        if resp.status_code == 200:
            data = resp.json()
            self.sa_token = data.get("access_token")
            print(f"✓ SA registered successfully")
            print_response("Response", data)
            return True
        else:
            print(f"✗ Registration failed: {resp.status_code}")
            print(resp.text)
            return False
    
    def login_sa(self, email, password="test123"):
        """Login as SA."""
        print(f"Logging in as SA: {email}")
        
        resp = requests.post(f"{self.base_url}/api/auth/login", json={
            "email": email,
            "password": password
        })
        
        if resp.status_code == 200:
            data = resp.json()
            self.sa_token = data.get("access_token")
            print(f"✓ Login successful")
            return True
        else:
            print(f"✗ Login failed: {resp.status_code}")
            return False
    
    def create_project(self, name="Test Project", scope="Salesforce Sales Cloud implementation"):
        """Create a new project."""
        print(f"Creating project: {name}")
        
        headers = {"Authorization": f"Bearer {self.sa_token}"}
        resp = requests.post(f"{self.base_url}/api/projects", json={
            "name": name,
            "scope": scope
        }, headers=headers)
        
        if resp.status_code == 200:
            data = resp.json()
            self.project_id = data.get("id")
            print(f"✓ Project created with ID: {self.project_id}")
            print_response("Response", data)
            return True
        else:
            print(f"✗ Project creation failed: {resp.status_code}")
            print(resp.text)
            return False
    
    def add_stakeholder(self, email=None, name="Test Stakeholder"):
        """Add a stakeholder to the project."""
        email = email or random_email()
        print(f"Adding stakeholder: {email}")
        
        headers = {"Authorization": f"Bearer {self.sa_token}"}
        resp = requests.post(f"{self.base_url}/api/projects/{self.project_id}/users", json={
            "email": email,
            "name": name
        }, headers=headers)
        
        if resp.status_code == 200:
            data = resp.json()
            self.invite_token = data.get("invite_token")
            print(f"✓ Stakeholder added")
            print(f"  Invite token: {self.invite_token}")
            print_response("Response", data)
            return email
        else:
            print(f"✗ Add stakeholder failed: {resp.status_code}")
            print(resp.text)
            return None
    
    def register_stakeholder(self, email, password="test123", name="Test Stakeholder"):
        """Register as a stakeholder using invite token."""
        print(f"Registering stakeholder: {email}")
        
        resp = requests.post(f"{self.base_url}/api/auth/register", json={
            "email": email,
            "password": password,
            "name": name,
            "invite_token": self.invite_token
        })
        
        if resp.status_code == 200:
            data = resp.json()
            self.stakeholder_token = data.get("access_token")
            print(f"✓ Stakeholder registered successfully")
            return True
        else:
            print(f"✗ Stakeholder registration failed: {resp.status_code}")
            print(resp.text)
            return False
    
    def submit_assessment(self, responses=None):
        """Submit communication style assessment."""
        print("Submitting communication style assessment...")
        
        # Default assessment responses (5 questions, ranks 1-4 for A,B,C,D)
        if responses is None:
            responses = [
                {"A": 2, "B": 1, "C": 3, "D": 4},  # Big-picture primary
                {"A": 3, "B": 4, "C": 2, "D": 1},  # Problem-focused
                {"A": 2, "B": 1, "C": 4, "D": 3},  # Big-picture
                {"A": 3, "B": 2, "C": 4, "D": 1},  # Problem-focused
                {"A": 4, "B": 1, "C": 3, "D": 2},  # Big-picture
            ]
        
        headers = {"Authorization": f"Bearer {self.stakeholder_token}"}
        resp = requests.post(f"{self.base_url}/api/session/assessment", json={
            "responses": responses
        }, headers=headers)
        
        if resp.status_code == 200:
            data = resp.json()
            print(f"✓ Assessment submitted")
            print_response("Response", data)
            return True
        else:
            print(f"✗ Assessment submission failed: {resp.status_code}")
            print(resp.text)
            return False
    
    def send_message(self, message, show_response=True):
        """Send a message in discovery session."""
        print(f"\n> User: {message}")
        
        headers = {"Authorization": f"Bearer {self.stakeholder_token}"}
        resp = requests.post(f"{self.base_url}/api/session/message", json={
            "message": message
        }, headers=headers)
        
        if resp.status_code == 200:
            data = resp.json()
            ai_message = data.get("message", "")
            if show_response:
                # Truncate for readability
                display_msg = ai_message[:800] + "..." if len(ai_message) > 800 else ai_message
                print(f"\n< AI: {display_msg}")
            
            # Check for phase completion
            if data.get("phase_complete_suggested"):
                print("\n[Phase completion suggested by AI]")
            
            return data
        else:
            print(f"✗ Message failed: {resp.status_code}")
            print(resp.text)
            return None
    
    def get_session_status(self):
        """Get current session status."""
        headers = {"Authorization": f"Bearer {self.stakeholder_token}"}
        resp = requests.get(f"{self.base_url}/api/session", headers=headers)
        
        if resp.status_code == 200:
            return resp.json()
        return None
    
    def approve_summary(self, action="approve", feedback=None):
        """Approve or request changes to phase summary."""
        print(f"Summary action: {action}")
        
        headers = {"Authorization": f"Bearer {self.stakeholder_token}"}
        body = {"action": action}
        if feedback:
            body["feedback"] = feedback
        
        resp = requests.post(f"{self.base_url}/api/session/approve-summary", 
                           json=body, headers=headers)
        
        if resp.status_code == 200:
            print(f"✓ Summary {action}d")
            return resp.json()
        else:
            print(f"✗ Summary action failed: {resp.status_code}")
            print(resp.text)
            return None
    
    def run_discovery_conversation(self, messages):
        """Run through a list of discovery messages."""
        for msg in messages:
            result = self.send_message(msg)
            if result is None:
                print("Stopping due to error")
                break
            time.sleep(1)  # Small delay between messages


def test_full_flow():
    """Test the complete SA → Stakeholder → Discovery flow."""
    tester = XPArchitectTester()
    
    # SA Flow
    print_section("SA REGISTRATION")
    if not tester.register_sa():
        return
    
    print_section("CREATE PROJECT")
    if not tester.create_project(
        name="Acme Corp Salesforce Implementation",
        scope="Salesforce Sales Cloud implementation with custom reporting and Outlook integration"
    ):
        return
    
    print_section("ADD STAKEHOLDER")
    stakeholder_email = tester.add_stakeholder(name="John Smith (Sales Manager)")
    if not stakeholder_email:
        return
    
    # Stakeholder Flow
    print_section("STAKEHOLDER REGISTRATION")
    if not tester.register_stakeholder(stakeholder_email, name="John Smith"):
        return
    
    print_section("COMMUNICATION ASSESSMENT")
    if not tester.submit_assessment():
        return
    
    print_section("DISCOVERY SESSION - PHASE 1")
    
    # Sample discovery conversation
    discovery_messages = [
        "Hi! I'm John, the Sales Manager at Acme Corp. I manage a team of 15 sales reps.",
        
        "Our current process is pretty chaotic honestly. Reps track their deals in spreadsheets, "
        "some use the old CRM, and a few just keep notes in their email. There's no consistency.",
        
        "The biggest pain point is forecasting. I spend every Friday afternoon calling reps "
        "to get their pipeline updates. Then I manually compile everything into a report for leadership. "
        "It takes me 4-5 hours and it's always outdated by Monday.",
        
        "We tried to standardize on the old CRM but adoption was terrible. The interface was clunky "
        "and reps said it took too long to log their activities. They need something mobile-friendly "
        "since they're on the road a lot.",
        
        "For tools, we use Outlook for email, the old CRM (barely), Excel for everything else, "
        "and Slack for team communication. Oh, and we have a separate system for quotes that doesn't "
        "talk to anything else.",
        
        "What works well? Honestly, the team itself. We have good people who close deals. "
        "The problem is visibility and process. I don't know what's happening until deals close or die.",
    ]
    
    tester.run_discovery_conversation(discovery_messages)
    
    print_section("SESSION STATUS")
    status = tester.get_session_status()
    if status:
        print_response("Current session", status)
    
    print_section("TEST COMPLETE")
    print("Full flow executed successfully!")
    print(f"\nProject ID: {tester.project_id}")
    print(f"Invite Token: {tester.invite_token}")


def test_api_health():
    """Quick test to verify API is responding."""
    print_section("API HEALTH CHECK")
    
    try:
        resp = requests.get(f"{BASE_URL}/docs", timeout=10)
        if resp.status_code == 200:
            print(f"✓ API is responding at {BASE_URL}")
            return True
        else:
            print(f"✗ API returned status {resp.status_code}")
            return False
    except Exception as e:
        print(f"✗ Could not connect to API: {e}")
        return False


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == "health":
        test_api_health()
    else:
        if test_api_health():
            test_full_flow()
