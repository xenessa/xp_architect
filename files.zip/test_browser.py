"""
XP Architect E2E Browser Test
Uses Playwright to automate the browser - you can watch it run!

Setup:
  pip install playwright
  playwright install chromium

Run (headed - you can watch):
  python test_browser.py

Run (headless - faster, no UI):
  python test_browser.py --headless
"""

import asyncio
import random
import string
import sys
from playwright.async_api import async_playwright

# Configuration
FRONTEND_URL = "https://xparchitectfrontend-production-da80.up.railway.app"  # Update this
SLOW_MO = 500  # Milliseconds between actions (makes it easier to watch)

def random_email():
    suffix = ''.join(random.choices(string.ascii_lowercase + string.digits, k=8))
    return f"test_{suffix}@example.com"

def print_step(step):
    print(f"\n{'='*50}")
    print(f"  {step}")
    print(f"{'='*50}")


async def test_sa_flow(page, sa_email, sa_password="test123"):
    """Test the Solution Architect flow."""
    
    print_step("1. SA REGISTRATION")
    
    # Navigate to register page
    await page.goto(f"{FRONTEND_URL}/register")
    await page.wait_for_load_state("networkidle")
    
    # Fill registration form
    await page.fill('input[name="name"], input[placeholder*="name" i]', "Test SA User")
    await page.fill('input[name="email"], input[type="email"]', sa_email)
    await page.fill('input[name="password"], input[type="password"]', sa_password)
    
    # Select SA role if there's a dropdown
    role_select = page.locator('select[name="role"], select:has-text("role")')
    if await role_select.count() > 0:
        await role_select.select_option("SA")
    
    # Submit
    await page.click('button[type="submit"], button:has-text("Register")')
    await page.wait_for_load_state("networkidle")
    
    print("✓ SA registered and logged in")
    
    # Take screenshot
    await page.screenshot(path="screenshots/01_sa_dashboard.png")
    
    return True


async def test_create_project(page):
    """Create a new project."""
    
    print_step("2. CREATE PROJECT")
    
    # Click create project button
    await page.click('button:has-text("Create"), button:has-text("New Project"), a:has-text("Create")')
    await page.wait_for_load_state("networkidle")
    
    # Fill project form
    await page.fill('input[name="name"], input[placeholder*="project" i]', "Acme Corp Implementation")
    
    # Fill scope - might be input or textarea
    scope_field = page.locator('textarea[name="scope"], input[name="scope"], textarea[placeholder*="scope" i]')
    await scope_field.fill("Salesforce Sales Cloud implementation with reporting and Outlook integration")
    
    # Submit
    await page.click('button[type="submit"], button:has-text("Create")')
    await page.wait_for_load_state("networkidle")
    
    print("✓ Project created")
    await page.screenshot(path="screenshots/02_project_created.png")
    
    return True


async def test_add_stakeholder(page, stakeholder_email):
    """Add a stakeholder to the project."""
    
    print_step("3. ADD STAKEHOLDER")
    
    # Click add stakeholder button
    await page.click('button:has-text("Add"), button:has-text("Stakeholder"), button:has-text("Invite")')
    await page.wait_for_timeout(500)
    
    # Fill stakeholder details
    await page.fill('input[name="email"], input[type="email"]', stakeholder_email)
    await page.fill('input[name="name"], input[placeholder*="name" i]', "John Smith")
    
    # Submit
    await page.click('button[type="submit"], button:has-text("Add"), button:has-text("Invite")')
    await page.wait_for_load_state("networkidle")
    
    print("✓ Stakeholder added")
    
    # Try to get invite link
    invite_link = None
    try:
        # Look for the invite link text
        link_element = page.locator('text=/invite.*token/i, input[value*="invite"], [data-invite-link]')
        if await link_element.count() > 0:
            invite_link = await link_element.first.text_content()
            if not invite_link:
                invite_link = await link_element.first.get_attribute("value")
    except:
        pass
    
    await page.screenshot(path="screenshots/03_stakeholder_added.png")
    
    return invite_link


async def test_stakeholder_registration(page, context, invite_url, stakeholder_email, password="test123"):
    """Register as stakeholder using invite link."""
    
    print_step("4. STAKEHOLDER REGISTRATION")
    
    # Open new page (simulates incognito/different user)
    stakeholder_page = await context.new_page()
    
    # Navigate to invite link or register page with token
    await stakeholder_page.goto(invite_url or f"{FRONTEND_URL}/register")
    await stakeholder_page.wait_for_load_state("networkidle")
    
    # Fill registration form
    name_field = stakeholder_page.locator('input[name="name"], input[placeholder*="name" i]')
    if await name_field.count() > 0 and not await name_field.input_value():
        await name_field.fill("John Smith")
    
    email_field = stakeholder_page.locator('input[name="email"], input[type="email"]')
    if await email_field.count() > 0 and not await email_field.input_value():
        await email_field.fill(stakeholder_email)
    
    await stakeholder_page.fill('input[name="password"], input[type="password"]', password)
    
    # Submit
    await stakeholder_page.click('button[type="submit"], button:has-text("Register")')
    await stakeholder_page.wait_for_load_state("networkidle")
    
    print("✓ Stakeholder registered")
    await stakeholder_page.screenshot(path="screenshots/04_stakeholder_registered.png")
    
    return stakeholder_page


async def test_assessment(page):
    """Complete the communication style assessment."""
    
    print_step("5. COMMUNICATION ASSESSMENT")
    
    # The assessment has 5 questions with rank inputs for A, B, C, D
    for q in range(1, 6):
        print(f"  Answering question {q}...")
        
        # Fill ranks (1-4) for each option
        # These might be inputs, dropdowns, or drag-and-drop
        try:
            # Try input fields
            await page.fill(f'input[name="q{q}a"], input[data-question="{q}"][data-option="A"]', "2")
            await page.fill(f'input[name="q{q}b"], input[data-question="{q}"][data-option="B"]', "1")
            await page.fill(f'input[name="q{q}c"], input[data-question="{q}"][data-option="C"]', "3")
            await page.fill(f'input[name="q{q}d"], input[data-question="{q}"][data-option="D"]', "4")
        except:
            # Try clicking through if it's a different UI pattern
            pass
        
        await page.wait_for_timeout(300)
    
    # Submit assessment
    await page.click('button[type="submit"], button:has-text("Submit"), button:has-text("Continue")')
    await page.wait_for_load_state("networkidle")
    
    print("✓ Assessment completed")
    await page.screenshot(path="screenshots/05_assessment_complete.png")
    
    return True


async def test_discovery_chat(page):
    """Have a discovery conversation."""
    
    print_step("6. DISCOVERY SESSION")
    
    messages = [
        "Hi, I'm John, Sales Manager at Acme Corp. I manage 15 sales reps.",
        "We currently track deals in spreadsheets. It's a mess with no consistency.",
        "My biggest pain is forecasting - I spend 4 hours every Friday compiling reports manually.",
        "We need something mobile-friendly since reps are on the road constantly.",
    ]
    
    for i, msg in enumerate(messages):
        print(f"\n  Sending message {i+1}/{len(messages)}...")
        print(f"  > {msg[:60]}...")
        
        # Find and fill chat input
        chat_input = page.locator('textarea, input[type="text"][placeholder*="message" i], input[placeholder*="type" i]')
        await chat_input.fill(msg)
        
        # Send message
        await page.click('button:has-text("Send"), button[type="submit"]')
        
        # Wait for response
        await page.wait_for_timeout(3000)  # Wait for AI response
        
        # Take screenshot
        await page.screenshot(path=f"screenshots/06_chat_{i+1}.png")
    
    print("\n✓ Discovery messages sent")
    return True


async def main(headless=False):
    """Run the full E2E test."""
    
    # Create screenshots directory
    import os
    os.makedirs("screenshots", exist_ok=True)
    
    sa_email = random_email()
    stakeholder_email = random_email()
    
    print(f"\nTest emails:")
    print(f"  SA: {sa_email}")
    print(f"  Stakeholder: {stakeholder_email}")
    
    async with async_playwright() as p:
        # Launch browser (headed = visible, slow_mo = slowed down for watching)
        browser = await p.chromium.launch(
            headless=headless,
            slow_mo=SLOW_MO if not headless else 0
        )
        
        context = await browser.new_context(
            viewport={"width": 1280, "height": 800}
        )
        
        page = await context.new_page()
        
        try:
            # SA Flow
            await test_sa_flow(page, sa_email)
            await test_create_project(page)
            invite_url = await test_add_stakeholder(page, stakeholder_email)
            
            # Stakeholder Flow
            stakeholder_page = await test_stakeholder_registration(
                page, context, invite_url, stakeholder_email
            )
            await test_assessment(stakeholder_page)
            await test_discovery_chat(stakeholder_page)
            
            print_step("TEST COMPLETE!")
            print("Screenshots saved to ./screenshots/")
            
        except Exception as e:
            print(f"\n✗ Test failed: {e}")
            await page.screenshot(path="screenshots/error.png")
            raise
        
        finally:
            await browser.close()


if __name__ == "__main__":
    headless = "--headless" in sys.argv
    asyncio.run(main(headless=headless))
